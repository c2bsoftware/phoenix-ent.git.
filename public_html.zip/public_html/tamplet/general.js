function gt(a,b){
	return(a>b)
}

function lt(a,b){
	return(a<b)
}

// var message="These images are copyright of Vixens London Escorts. Using these images without consent will lead to prosecution.";
// function clickIE(){if (document.all){return false;}}
// 
// function clickNS(e) {
// 	if(document.layers||(document.getElementById&&!document.all)){
// 		if (e.which==2||e.which==3) {return false;}
// 	}
// }
// 
// if (document.layers)
// 	{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
// else
// 	{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
//  
// document.oncontextmenu=new Function("alert(message);return false");
// 
(function($)
{
	$.fn.blink = function(options)
	{
		var defaults = { delay:500 };
		var options = $.extend(defaults, options);
		
		return this.each(function()
		{
			var obj = $(this);
			setInterval(function()
			{
				if($(obj).css("visibility") == "visible")
				{
					$(obj).css('visibility','hidden');
				}
				else
				{
					$(obj).css('visibility','visible');
				}
			}, options.delay);
		});
	}
}(jQuery))
